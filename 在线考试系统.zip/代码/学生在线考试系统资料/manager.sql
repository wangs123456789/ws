create table manager (id varchar2(20) primary key,name varchar2(20),password varchar2(20));
